## Overview

**CRASH20K**是一个面向 Data Lake(House) 场景下弱关联（Union关系）的表格数据集。该数据集聚焦于交通事故场景，包含两张弱关联的表格，分别为任务表（Maryland事故报告）和辅助表（Seattle事故报告）。任务表（Maryland.parquet）包含从2024年2月至2025年3月期间的交通事故记录，共计10,000条数据；辅助表（Seattle.parquet）包含2022年8月至2024年12月期间的交通事故记录，同样为10,000条数据。  

两张表之间存在弱关联（Union）关系，可以利用辅助表中的信息提升任务表的机器学习效果，以实现更精准的关联分析。

## Data Processing

CRASH20K 数据集包含两张弱关联的交通事故数据表（任务表与辅助表），数据来源为公开的交通事故报告。以下为数据处理步骤的详细说明：

**任务表：** Maryland事故报告（Maryland.parquet）  
- **数据来源：**[Crash Reporting - Incidents Data](https://catalog.data.gov/dataset/crash-reporting-incidents-data)  
- **数据清洗：**
删除 Collision Type（标签）列中类别为 OTHER、UNKNOWN、Other、Unknown 及空值的样本。  
- **数据筛选：**
根据 Crash Date/Time 列，选取日期最新的 10,000 条记录作为任务表数据。

**辅助表：** Seattle事故报告（Seattle.parquet）  
- **数据来源：**[SDOT Collisions All Years](https://catalog.data.gov/dataset/sdot-collisions-all-years-2a008)  
- **数据清洗：**
删除 COLLISIONTYPE（标签）列中类别为 other 及空值的样本。  
- **数据筛选：**
根据 INCDATE 列，选取日期最新的 10,000 条记录作为辅助表数据。

## Dataset Composition

- **Maryland.parquet** :该文件包含10000条事故记录，每条事故具有碰撞类型、报告编号、发生时间、车道方向、路线类型、天气情况，路面状况等37个特征。其中碰撞类型有8个类别：  
  * Sideswipe, Same Direction  
  * Front to Rear  
  * Single Vehicle  
  * Rear To Side  
  * Angle  
  * Sideswipe, Opposite Direction  
  * Front to Front  
  * Rear To Rear  
<p>

- **Seattle.parquet** :该文件包含10000条事故记录，每条事故具有碰撞类型、报告编号、发生时间、事故位置、严重程度，是否超速等37个特征。其中碰撞类型有9个类别：  
  * Rear Ended
  * Pedestrian
  * Sideswipe
  * Angles
  * Parked Car
  * Cycles
  * Left Turn
  * Head On
  * Right Turn

## References
